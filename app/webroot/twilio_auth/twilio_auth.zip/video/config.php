<?php
// see README.md for an explanation of these config params
$TWILIO_ACCOUNT_SID = 'ACc8400e4cd159ba80be171f2540d9e7db';
$TWILIO_API_KEY = 'SKac96043671f239406b5c4c9a0607cae6';
$TWILIO_API_SECRET = 'PExZPElncJ9VqGhpMLqHEM5y0DFzsKmf';
