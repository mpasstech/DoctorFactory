<?php
require_once './vendor/autoload.php';
include('./config.php');
use Twilio\Rest\Client;
$request = file_get_contents("php://input");
$data = json_decode($request, true);
$date = isset($data["date"]) ? $data["date"] :  "";
$to_number = isset($data["to_number"]) ? $data["to_number"] :  "";
$body = isset($data["body"]) ? $data["body"] :  "";
$twilio = new Client($ACCOUNT_SID, $TOKEN);
$message = $twilio->messages
    ->create("whatsapp:$to_number", // to
        [
            "from" => "whatsapp:+19843004757",
            "body" => $body
        ]
    );
$response['sid'] = $message->sid;
$response['status'] = $message->status;
$response['errorCode'] = $message->errorCode;
echo json_encode($response);
?>