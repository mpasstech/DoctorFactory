<?php
$ACCOUNT_SID = 'AC***';
$API_KEY = 'SK***';
$API_KEY_SECRET = '***';
$PUSH_CREDENTIAL_SID = 'CR***';
$APP_SID = 'AP***';